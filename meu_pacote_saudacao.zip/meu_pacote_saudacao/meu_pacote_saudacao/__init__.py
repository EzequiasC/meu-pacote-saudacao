def saudacao(nome):
    return f"Olá, {nome}! Bem-vindo ao meu primeiro pacote Python."